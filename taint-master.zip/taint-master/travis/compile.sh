#!/bin/sh
phpize && ./configure && make 
